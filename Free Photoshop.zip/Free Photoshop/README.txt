////////////////This is my first virus////////////////

It was created using some YouTube tutorials.
Please only test this virus on a virtual machine!
The malware doesn't delete any critical system files,
but it causes a lot of graphical glitches!

To make sure the virus works properly, leave all the
files where they are and don't rename them.

If you want to start the virus, start "Free Photoshop.exe"


/////////////////Remove the virus///////////////////

1. After starting the virus, you have to wait until
   the system crashes and restarts.

2. The screen is black and some message boxes are 
   spaming. You have 45 seconds. If you are too 
   slow, you will experience more graphical glitches!

3. Press Ctrl + shift + esc to open the task manager

4. Click file --> new task and enter "explorer.exe"
   Now you should see your wallpaper again.

5. Press Windows key + r and enter 
   "taskkill /f /im cmd.exe"

6. Press Windows key + r and enter 
   "taskkill /f /im wscript.exe"

7. Press Windows key + r and enter
   "shell:startup" and delete every file that was 
   not created by you

8. Go to C:\Windows\Users\Your name\
   and delete the folder "0"

9. You removed my virus :)

10. Safety keys:  • Extract ZIP: 2718
                  • Start Virus: Destruction
                  • Decryption key Virus (doesn't help you): Emotional Damage




                  